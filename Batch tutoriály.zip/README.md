# Batch
### Obsah:

Na mém YouTube kanále natáčím tutoriály na programování v jazyce **Batch**. V této složce tedy naleznete soubory, které používám ve videích. Až budete dělat nějaký svůj program, klidně můžete použít části těchto souborů pro vlastní potřebu :D

*Odkaz na sérii batch tutoriálů: **[ZDE (youtube.com)](https://www.youtube.com/watch?v=zvVciqiWdhA&list=PLNAr42tFtus5RCve4wmJ8vSP1AK4ppIe- "Nejlepší batch série od Grizlik :D")***