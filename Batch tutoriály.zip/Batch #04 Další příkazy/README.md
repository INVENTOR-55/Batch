Jelikož **"Program.bat"** z videa stál za nic, tak je tato složka prázdná :DDD<br>
Tedy až na **"Batch 04.bat"**, který zde však přidám, až vyjde pátý díl do této série