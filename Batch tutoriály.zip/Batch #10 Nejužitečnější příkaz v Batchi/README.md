**"Soubory.bat"** je program pro zkopírování všech souborů ve zdrojové složce do cílové složky. K tomuto kopírování je však použitý příkaz ***forfiles***, což způsobí, že jestliže cesta k cílové složce kdekoliv obsahuje mezeru, program nebude fungovat

Až vyjde 11. díl do této série, tak zde nahraji i **"Batch 10.bat"** z konce videa