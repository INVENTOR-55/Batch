Program **"get.bat"** vyhledá a provede instalaci programu, jehož název uživatel zadá jako parametr do příkazového řádku<br>
**"makra.bat"** obsahuje ukázku definicí maker pro příkazový řádek. Po spuštění tohoto souboru bude v daném příkazovém řádku možné používat nové příkazy ***ls*** a ***ahoj***<br>
Soubor **"novy.bat"** vytvoří nový soubor se zadaným názvem v aktuální složce<br>
**"youtube.bat"** po spuštění otevře webovou stránku ***www.youtube.com***

Po vydání 15. dílu do této série zde přibyde i soubor **"Batch 14.bat"**, zadaný na konci videa