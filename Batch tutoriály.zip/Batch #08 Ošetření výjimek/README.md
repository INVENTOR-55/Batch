**Oprava.bat** se uživatele zeptá příkazem choice, jestli chce spustit příkaz *sfc /scannow*, pokud uživatel dá ano, tak program zkontroluje, jestli je spuštěn s oprávněním správce, pokud ano, *sfc /scannow* se spustí<br>
**Správce.bat** je program ke kontrole zvýšených oprávnění. Vypíše text podle toho, jestli je nebo není spuštěn s oprávněním správce.<br>
**Sudé nebo liché.bat** po vás požaduje zadání libovolného čísla a pak zkontroluje zbytek tohoto čísla po vydělení dvěma. Pokud je zbytek 1, číslo je liché, pokud 0, číslo je sudé.<br>
**Zbytek.bat** je program k ukázce výpočtu zbytku po dělení dvou čísel<br>
Po vydání devátého dílu do této série zde nahraji i program **Batch 08.bat**, který jsem zadával na konci tohoto videa.