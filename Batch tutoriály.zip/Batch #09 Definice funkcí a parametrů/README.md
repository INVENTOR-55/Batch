**"Čtverec.bat"** slouží jako nápověda k **"Batch 09.bat"**. Do programu zadáte stranu čtverce a pomocí funkcí vám program vypočítá obvod a obsah<br>
**"Funkce.bat"** je program k ukázce chování funkcí a příkazu ***call*** a vytváření funkcí<br>
**"JeCislo.bat"** a **"Overeni pro cislo.bat"** jsou spolupracující programy za použití příkazu ***call***, pro správné fungování musí být ve stejné složce<br>
**"JeCislo2.bat"** a **"Lokalni promenne externi.bat"** jsou také spolupracující programy, které používají příkazy ***SETLOCAL*** a ***ENDLOCAL***, aby nedoško ke konfliktu názvů proměnných<br>
**"Lokální a globální proměnné.bat"** ukazuje využití příkazů ***SETLOCAL*** a ***ENDLOCAL*** a ukazuje rozdíl mezi globálními a lokálními proměnnými<br>
**"Lokální proměnné error.bat"** je program, využívající pomocnou proměnnou uvnitř funkce, která však přepíše naprosto nesouvisející proměnnou, protože má stejný název <br>
**"Lokální proměnné.bat"** řeší tento problém se stejným názvem proměnných pomocí vytváření lokálních proměnných<br>
**"Ověření pro číslo bez funkcí.bat"** a **"Ověření pro číslo pomocí funkcí.bat"** je stejný program k ukázce, jaká je výhoda funkcí. Tento program kontroluje, jestli uživatel zadal číslo tak, že pokud příkaz ***set /a*** obdrží jako hodnotu proměnné nějaký text, tak se do proměnné uloží nula<br>
**"Parametry funkce.bat"** je program, který spustí funkci s parametry a vypíše její první parametr<br>
**"Parametry souboru.bat"** je program, který kontroluje, jestli byl spuštěn s parametrem */vypis*<br>
**"Rickroll bez funkcí.bat"** a **"Rickroll pomocí funkcí.bat"** vypisuje rickroll text a pak vždy sekundu čeká. Na programu je ukázána výhoda použití funkcí, proti klasickému výpisu

Až vyjde 10. (a trochu speciální) díl do série na Batch, tak zde nahraji i program **"Batch 09.bat"** zadaný na konci videa