**Cmd.bat** se vás zeptá na zadání libovolného textu, který se poté spustí jako příkaz<br>
**Část proměnné.bat** není program z videa. Rozhodl jsem se vytvořit program, ve kterém budou použity všechny varianty výpisu části proměnné, protože tohle téma je poměrně složité na pochopení<br>
**Nevýhody.bat** ukazuje nevýhody dosazování hodnot za proměnné předem. Program za proměnnou ***vysledek*** dosadí hodnotu ***10*** ještě dříve, než se stihne provést výpočet<br>
**Proměnné.bat** je program, který ukazuje, jak batch zpracovává proměnné, podle toho, co zadáte do proměnné ***a***, takový příkaz se spustí spolu s textem ***taskmgr.exe***<br>
Až vyjde 8. díl do této série, přidám zde i mou verzi programu **Batch 07.bat** z konce videa