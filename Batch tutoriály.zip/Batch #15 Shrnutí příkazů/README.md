Program **"handbrake.bat"** kontroluje, jestli běží proces s názvem *"HandBrake.exe"*. Jakmile tento proces neběží, po 60 sekundách restartuje počítač<br>
**"hashcat.bat"** spouští program *"C:\Program Files\hashcat-6.2.6\hashcat.exe"* s parametry předanými z příkazového řádku<br>
Program **hudba.bat** převede přes ***ffmpeg*** všechny soubory s příponou *.webm* v aktuální složce na příponu *.mp3*