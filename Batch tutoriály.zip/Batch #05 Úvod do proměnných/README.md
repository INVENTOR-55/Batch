Program **"goto.bat"** vysvětluje příkaz ***goto***<br>
**"Program.bat"** slouží k ukázce matematiky v batchi<br>
**"Random.bat"** a **"Random 2.bat"** slouží k vygenerování náhodného čísla v určitém rozsahu<br>
**"Vypnutí vypnutí xD.bat"** slouží ke zrušení vypínání počítače pomocí příkazu ***shutdown***<br>
A až vyjde šestý díl těchto tutoriálů, tak zde přidám i soubor **"Batch 05.bat"**, který jsem zadával na konci minulého videa