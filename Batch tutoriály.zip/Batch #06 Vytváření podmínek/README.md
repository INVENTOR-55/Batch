**"Delete.bat"** a **"Delete 2.bat"** vymažou soubor ***Soubor.txt***. **"Delete 2.bat"** je však pomocí podmínek vylepšený, aby kontroloval, jestli soubor opravdu existuje<br>
**"Else.bat"** slouží k ukázce příkazu ***else***<br>
**"if.bat"** je shrnutí všech variant příkazu ***if*** ve videu<br>
**"Porovnani.bat"** ukazuje všechny možnosti, jak v batchi porovnat dvě čísla<br>
**"Procento nula.bat"** vypíše obsah "proměnné" ***%0***, neboli cestu k tomu souboru<br>
**"Program.bat"** je základní program k ukázce, jak fungují podmínky<br>
**"Soubor.bat"** vytvoří soubor s názvem ***Soubor.txt*** a **"Soubor 2.bat"** i kontroluje, jestli ***Soubor.txt*** existuje, aby nedošlo k přepsání dat uvnitř souboru<br>
Až vyjde 7. díl do této série, tak zde přidám i **"Batch 06.bat"**, neboli řešení úkolu z konce minulého videa